// P1
// Creează două array-uri
let fructe = ['măr', 'portocală'];
let legume = ['morcov', 'broccoli'];

// Concatenează-le într-un singur array numit alimente
let alimente = fructe.concat(legume);

console.log(alimente); // Afișează: ['măr', 'portocală', 'morcov', 'broccoli']


// P2
// Creează un array de cuvinte
let fructe2 = ['măr', 'portocală', 'banana'];

// Verifică dacă 'struguri' se regăsește în array utilizând indexOf
let rezultat = fructe2.indexOf('struguri') !== -1;

console.log(rezultat); // Afișează: false (deoarece 'struguri' nu se regăsește în array)


//P3
// Creează un obiect Date
let currentDate = new Date();

// Afișează anul curent în consolă
console.log(currentDate.getFullYear()); // Afișează anul curent


//P4
// Creează un obiect Date
let currentDate2 = new Date();

// Adaugă 5 zile la data curentă
currentDate2.setDate(currentDate2.getDate() + 5);

// Afișează noua dată în consolă
console.log(currentDate2);


//P5
// Creează două obiecte Date reprezentând două momente în timp
let timestamp1 = new Date('2022-01-01').getTime();
let timestamp2 = new Date('2022-02-01').getTime();

// Calculează diferența dintre ele în milisecunde
let diferentaInMilisecunde = timestamp2 - timestamp1;

// Afișează rezultatul în consolă
console.log(diferentaInMilisecunde);


//P6
// Creează un obiect cu informații despre tine
let persoana = { nume: 'NumeleTau', varsta: 25, oras: 'OrasulTau' };

// Afișează obiectul în consolă
console.log(persoana);


//P7
// Modifică vârsta persoanei din obiectul creat anterior
persoana.varsta = 26;

// Afișează obiectul modificat în consolă
console.log(persoana);


//P8
// Creează un array de obiecte reprezentând cărți
let carti = [
    { titlu: 'Carte1', autor: 'Autor1', anPublicare: 2000 },
    { titlu: 'Carte2', autor: 'Autor2', anPublicare: 1995 }
  ];
  
// Folosește o metodă a array-ului pentru a adăuga încă un obiect reprezentând o carte
carti.push({ titlu: 'Carte3', autor: 'Autor3', anPublicare: 2021 });

// Afișează array-ul de cărți în consolă
console.log(carti);
  