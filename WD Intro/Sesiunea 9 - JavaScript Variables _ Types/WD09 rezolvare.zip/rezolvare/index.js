//Declară o variabilă pentru vârsta ta și afișează-o în consolă.
let age = 25;
console.log(age);

// Calculează suma a două numere și afișează rezultatul.
let num1 = 10;
let num2 = 5;
let sum = num1 + num2;
console.log(sum);

//Declarați o variabilă pentru temperatura în grade Celsius și convertiți-o în Fahrenheit.
let celsiusTemperature = 30;
let fahrenheitTemperature = (celsiusTemperature * 9/5) + 32;
console.log(fahrenheitTemperature);

// Atribuiți unui șir de caractere valoarea "Hello, " și adăugați numele tău, apoi afișați rezultatul.
let greeting = "Hello, ";
let myName = "John";
let fullGreeting = greeting + myName;
console.log(fullGreeting);

// Verificați dacă un număr este par sau impar și afișați rezultatul.
let numberToCheck = 7;
let isEven = numberToCheck % 2 === 0
console.log("Numărul este par: ", isEven);

// Declarați o variabilă booleană pentru a verifica dacă sunteți student sau nu.
let isStudent = true;
console.log(isStudent);

// Declarați două variabile de tip șir de caractere și concatenați-le.
let firstName = "John";
let lastName = "Doe";
let fullName = firstName + " " + lastName;
console.log(fullName);

// Calculați restul împărțirii a două numere și afișați rezultatul.
let dividend = 17;
let divisor = 5;
let remainder = dividend % divisor;
console.log(remainder);

// Declară o variabilă și atribuie-i valoarea undefined, apoi afișează rezultatul.
let undefinedVariable;
console.log(undefinedVariable);

// Calculează aria unui dreptunghi folosind lungimea și lățimea.
let length = 10;
let width = 5;
let area = length * width;
console.log(area);

// Verificați dacă două șiruri de caractere sunt identice și afișați rezultatul.
let str1 = "Hello";
let str2 = "Hello";
console.log("Șirurile sunt identice.", str1 === str2);

// Declarați două variabile booleane și efectuați operații logice pe acestea.
let condition1 = true;
let condition2 = false;
console.log(condition1 && condition2); // false
console.log(condition1 || condition2); // true
console.log(!condition1); // false

// Declară o variabilă pentru anul de naștere și calculează vârsta.
let birthYear = 1990;
let currentYear = new Date().getFullYear();
let myAge = currentYear - birthYear;
console.log(myAge);

// Concatenează două șiruri de caractere și convertește rezultatul în majuscule.
let str3 = "Hello";
let str4 = "World";
let concatenatedStr = str3 + " " + str4;
let upperCaseStr = concatenatedStr.toUpperCase();
console.log(upperCaseStr);

// Verifică dacă un număr este mai mare sau egal cu 100 și afișează rezultatul.
let numToCheck = 120;
let isGreaterOrEqual = numToCheck >= 100;
console.log("Numărul este mai mare sau egal cu 100. ", isGreaterOrEqual);


// Declarați o variabilă pentru distanța în kilometri și convertește-o în mile.
let distanceInKm = 50;
let distanceInMiles = distanceInKm * 0.621371;
console.log(distanceInMiles);

// Atribuiți unui număr valoarea null și verificăți tipul de date.
let nullNumber = null;
console.log(typeof nullNumber); // object

// Declarați două numere și afisati dacă sunt egale.
let num5 = 10;
let num6 = 10;
let numbersAreEqual = num5 === num6;
console.log("Numerele sunt egale: ", numbersAreEqual);

// Declară o variabilă pentru prețul unui produs și aplică o reducere.
let productPrice = 50;
let discount = 0.1; // 10%
let discountedPrice = productPrice - (productPrice * discount);
console.log(discountedPrice);