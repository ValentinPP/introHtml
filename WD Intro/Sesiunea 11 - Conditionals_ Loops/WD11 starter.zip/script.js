/**
* Numere Pare și Impare: 
* Scrie un program care afișează toate numerele pare de la 1 la 20
* și toate numerele impare de la 1 la 20.
*/
 
/**
* Verificare Număr Prim: 
* Scrie un program care verifică dacă un numar este prim.
*/

/**
* Suma Multiplilor de 3 și 5: 
* Calculează suma tuturor numerelor întregi 
* până la 100 care sunt multipli de 3 sau 5.
*/

/**
* Afișarea Elementelor Șirului: 
* Creează un șir cu câteva cuvinte și folosește o buclă 
* 'for' pentru a afișa fiecare cuvânt în consolă.
*/

/**
* Verificare Palindrom: 
* Scrie un program care verifică dacă un cuvant
* este un palindrom (se citește la fel de la stânga la 
* dreapta și de la dreapta la stânga, ignorând spațiile și diferențele de majuscule)
*/

/**
 * Calculează suma pătratelor numerelor de la 1 la 10.
 */

/**
 * Determinarea Parității: 
 * Se da un array const nums = [1, 12, 30, 21]
 * Scrie un program care afișează un mesaj 
 * care indică pentru fiecare numar din array dacă numărul este par sau impar.
 */

/**
 * Numere Prime în Interval: 
 * Se dau două numere x = 12, y = 35, afișează toate numerele prime din intervalul x, y.
 */

/**
 * Afișarea Tabelului de Multiplicare: 
 * Afiseaza tabelul de multiplicare de la 1 la 10 (tabla inmultirii).
 */

/**
 * Jocul de FizzBuzz:
 * Scrie un program care afișează numerele de la 1 la 50. 
 * Pentru fiecare multiplu de 3, afișează "Fizz". 
 * Pentru fiecare multiplu de 5, afișează "Buzz". 
 * Pentru numerele care sunt simultan multipli de 3 și 5, afișează "FizzBuzz".
 */
